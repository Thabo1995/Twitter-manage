package service;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.faces.bean.ApplicationScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import model.TwitterEntity;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.auth.AccessToken;
import twitter4j.conf.ConfigurationBuilder;
import twitter4j.*;

@Stateless
@LocalBean
@ApplicationScoped
public class TwitterEJB {

	@PersistenceContext
	private EntityManager em;

	public TwitterEJB() {
	}


	public static ConfigurationBuilder configBuilder() {
		// making it easy to use the configuration builder
		String OAuthConsumerKey = "UwfCIrN2mKF9NxGjNcvqSnLDF";
		String OAuthConsumerSecret = "4l4aQcvFxV5YPzsX0Fl2sks90n6Gz6BPQuwg1BY4ysK9pZ0TlK";
		String OAuthAccessToken ="2471709515-DhH8v4mlbcBKNscPLmFo5wccYoY9PKXbPq04GiP";
		String OAuthAccessTokenSecret = "ZgkmjhMaFZ5vGSpMmhELEIQwpIA16bY6sZ8BvmZsMOTsX";
		
	       ConfigurationBuilder cb = new ConfigurationBuilder();
	       cb.setDebugEnabled(true)
	           .setOAuthConsumerKey(OAuthConsumerKey)
	           .setOAuthConsumerSecret(OAuthConsumerSecret)
	           .setOAuthAccessToken(OAuthAccessToken)
	           .setOAuthAccessTokenSecret(OAuthAccessTokenSecret);
	       return cb;
	}
	public void sendDirectMessages(String message) 
			  throws TwitterException {
		
	    	TwitterFactory tf = new TwitterFactory(configBuilder().build());
	    	twitter4j.Twitter t4w =  tf.getInstance();
	    	
	    	DirectMessage msg = t4w.sendDirectMessage("@AdhLecturer",message);

//	    	DirectMessage msg = t4w.sendDirectMessage("@herongwako",message);
//	    	DirectMessage msg = t4w.sendDirectMessage("@209152100_ADH", message);
	       System.out.println("Message sent " + msg);
	}
	public void sendTweet(TwitterEntity twitterEntity) {
		//post on twitter
	
		//post to DB
		if(twitterEntity.getTweetBody().isEmpty()) {
			System.out.println("nothing to post");
		}else {
		       try 
		       {
		          TwitterFactory factory = new TwitterFactory(configBuilder().build());
		          Twitter twitter = factory.getInstance();
		          System.out.println(twitter.getScreenName());
		          //update status
		          Status status = twitter.updateStatus(twitterEntity.getTweetBody());
		          System.out.println("Successfully updated the status to [" + status.getText() + "].");
		           }catch (TwitterException te) {
		              te.printStackTrace();
		              System.exit(-1);
		       }
			System.out.println("Message posted = " + twitterEntity.getTweetBody());
			em.persist(twitterEntity);
			System.out.println("=======================Tweet saved to DB=============");
		}
		
	}

	@SuppressWarnings("unchecked")
	public List<TwitterEntity> findAll(){
		return em.createQuery("SELECT tweetID,tweetBody, timeStamp FROM tweets").getResultList();

	}
}